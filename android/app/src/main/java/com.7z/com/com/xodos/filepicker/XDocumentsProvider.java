package com.com.xodos.filepicker;

import static android.provider.DocumentsContract.Document.MIME_TYPE_DIR;
import static android.system.OsConstants.S_IFLNK;
import static android.system.OsConstants.S_IFMT;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.ProviderInfo;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.graphics.Point;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.provider.DocumentsContract.Document;
import android.provider.DocumentsContract.Root;
import android.provider.DocumentsProvider;
import android.system.ErrnoException;
import android.system.Os;
import android.system.StructStat;
import android.util.Log;
import android.webkit.MimeTypeMap;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * XoDos DocumentsProvider - Works exactly like Termux MTFile provider
 * Fixed version with security improvements and deprecated API fixes
 */
public class XDocumentsProvider extends DocumentsProvider {
    private static final String TAG = "XDocumentsProvider";
    private static final String[] DEFAULT_ROOT_PROJECTION = {
        Root.COLUMN_ROOT_ID,
        Root.COLUMN_MIME_TYPES,
        Root.COLUMN_FLAGS,
        Root.COLUMN_ICON,
        Root.COLUMN_TITLE,
        Root.COLUMN_SUMMARY,
        Root.COLUMN_DOCUMENT_ID,
        Root.COLUMN_AVAILABLE_BYTES
    };

    private static final String[] DEFAULT_DOCUMENT_PROJECTION = {
        Document.COLUMN_DOCUMENT_ID,
        Document.COLUMN_MIME_TYPE,
        Document.COLUMN_DISPLAY_NAME,
        Document.COLUMN_LAST_MODIFIED,
        Document.COLUMN_FLAGS,
        Document.COLUMN_SIZE,
        "mt_extras"
    };

    private static final String VIRTUAL_FILES = "files";
    private static final String VIRTUAL_DATA = "data";
    
    private String pkgName;
    private File dataDir;      // /data/data/com.xodos
    private File filesDir;     // /data/data/com.xodos/files
    private File canonicalDataDir;
    private File canonicalFilesDir;
    
    // Caching
    private static final ConcurrentHashMap<String, String> MIME_CACHE = new ConcurrentHashMap<>();
    
    /**
     * Delete files in directory or soft link
     */
    private static boolean deleteFileOrDirectory(File file) {
        if (file.isDirectory()) {
            // Check if it's a symlink
            boolean isSymlink = false;
            try {
                isSymlink = (Os.lstat(file.getPath()).st_mode & S_IFMT) == S_IFLNK;
            } catch (ErrnoException e) {
                Log.e(TAG, "Error checking symlink", e);
                return false;
            }

            File[] subFiles = file.listFiles();
            if (!isSymlink && subFiles != null) {
                for (File sub : subFiles) {
                    if (!deleteFileOrDirectory(sub)) {
                        return false;
                    }
                }
            }
        }
        return file.delete();
    }

    private static String getMimeType(File file) {
        if (file.isDirectory()) {
            return MIME_TYPE_DIR;
        }

        String name = file.getName();
        int lastDot = name.lastIndexOf('.');
        if (lastDot >= 0) {
            String extension = name.substring(lastDot + 1).toLowerCase();
            String cached = MIME_CACHE.get(extension);
            if (cached != null) return cached;
            
            String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
            if (mime != null) {
                MIME_CACHE.put(extension, mime);
                return mime;
            }
        }
        return "application/octet-stream";
    }

    @SuppressLint("SdCardPath")
    @Override
    public final void attachInfo(Context context, ProviderInfo info) {
        super.attachInfo(context, info);
        if (context == null) {
            Log.e(TAG, "Context is null in attachInfo");
            return;
        }
        
        this.pkgName = context.getPackageName();
        this.dataDir = context.getFilesDir().getParentFile();
        this.filesDir = context.getFilesDir();
        
        try {
            this.canonicalDataDir = dataDir.getCanonicalFile();
            this.canonicalFilesDir = filesDir.getCanonicalFile();
        } catch (IOException e) {
            Log.e(TAG, "Error getting canonical paths", e);
            this.canonicalDataDir = dataDir;
            this.canonicalFilesDir = filesDir;
        }
        
        Log.d(TAG, "Provider initialized for package: " + pkgName);
        Log.d(TAG, "Data dir: " + dataDir);
        Log.d(TAG, "Files dir: " + filesDir);
    }

    /**
     * Security: Check if file is within allowed directories
     */
    private boolean isWithinAllowedDirectory(File file) {
        try {
            String filePath = file.getCanonicalPath();
            String dataPath = canonicalDataDir.getCanonicalPath();
            return filePath.startsWith(dataPath);
        } catch (IOException e) {
            Log.e(TAG, "Error checking file path", e);
            return false;
        }
    }

    /**
     * Get file object by documentId - This is the KEY function that creates the virtual mapping
     */
    private File getFileForDocId(String documentId, boolean lsFileState) throws FileNotFoundException {
        // Document ID format: com.xodos/files/path/to/file
        // or: com.xodos/data/path/to/file
        
        if (documentId == null || !documentId.startsWith(this.pkgName)) {
            throw new FileNotFoundException("Invalid document ID: " + documentId);
        }

        // Get the part after package name
        String virtualPath = documentId.substring(this.pkgName.length());
        if (virtualPath.startsWith("/")) {
            virtualPath = virtualPath.substring(1);
        }
        
        // Root directory - return null to indicate virtual root
        if (virtualPath.isEmpty()) {
            return null;
        }
        
        // Split into virtual directory and rest of path
        String[] parts = virtualPath.split("/", 2);
        String virtualDir = parts[0];
        String restPath = parts.length > 1 ? parts[1] : "";

        File targetFile;
        
        // Map virtual directories to real paths - EXACTLY like Termux
        if (virtualDir.equals(VIRTUAL_FILES)) {
            targetFile = new File(this.filesDir, restPath);
        } else if (virtualDir.equals(VIRTUAL_DATA)) {
            targetFile = new File(this.dataDir, restPath);
        } else {
            throw new FileNotFoundException("Unknown virtual directory: " + virtualDir);
        }

        // Security check
        if (targetFile != null && !isWithinAllowedDirectory(targetFile)) {
            throw new SecurityException("Access denied: Path traversal attempt");
        }

        if (lsFileState && targetFile != null) {
            try {
                Os.lstat(targetFile.getPath());
            } catch (Exception unused) {
                throw new FileNotFoundException(documentId.concat(" not found"));
            }
        }
        return targetFile;
    }

    @Override
    public final Bundle call(@NonNull String method, @Nullable String arg, @Nullable Bundle extras) {
        Bundle call = super.call(method, arg, extras);
        if (call != null) {
            return call;
        }

        if (!method.startsWith("mt:")) {
            return null;
        }

        Bundle customBundle = new Bundle();
        customBundle.putBoolean("result", false);
        try {
            if (extras == null) {
                customBundle.putString("message", "Extras bundle is null");
                return customBundle;
            }
            
            Uri uri = extras.getParcelable("uri");
            if (uri == null) {
                customBundle.putString("message", "URI is null");
                return customBundle;
            }
            
            List<String> pathSegments = uri.getPathSegments();
            String documentId = pathSegments.size() >= 4 ? pathSegments.get(3) : pathSegments.get(1);
            
            if (documentId == null) {
                customBundle.putString("message", "Document ID is null");
                return customBundle;
            }
            
            switch (method) {
                case "mt:setPermissions": {
                    File file = getFileForDocId(documentId, true);
                    if (file != null) {
                        int permissions = extras.getInt("permissions", -1);
                        if (permissions == -1) {
                            customBundle.putString("message", "Invalid permissions");
                        } else {
                            Os.chmod(file.getPath(), permissions);
                            customBundle.putBoolean("result", true);
                        }
                    } else {
                        customBundle.putString("message", "File not found");
                    }
                    break;
                }
                case "mt:createSymlink": {
                    File file = getFileForDocId(documentId, false);
                    if (file != null) {
                        String targetPath = extras.getString("path");
                        if (targetPath == null || targetPath.isEmpty()) {
                            customBundle.putString("message", "Target path is empty");
                        } else {
                            Os.symlink(targetPath, file.getPath());
                            customBundle.putBoolean("result", true);
                        }
                    } else {
                        customBundle.putString("message", "File not found");
                    }
                    break;
                }
                case "mt:setLastModified": {
                    File file = getFileForDocId(documentId, true);
                    if (file != null) {
                        long time = extras.getLong("time", -1);
                        if (time == -1) {
                            customBundle.putString("message", "Invalid time");
                        } else {
                            customBundle.putBoolean("result", file.setLastModified(time));
                        }
                    } else {
                        customBundle.putString("message", "File not found");
                    }
                    break;
                }
                case "mt:getPermissions": {
                    File file = getFileForDocId(documentId, true);
                    if (file != null) {
                        try {
                            StructStat stat = Os.lstat(file.getPath());
                            customBundle.putBoolean("result", true);
                            customBundle.putInt("permissions", stat.st_mode & 0777);
                            customBundle.putInt("uid", stat.st_uid);
                            customBundle.putInt("gid", stat.st_gid);
                        } catch (ErrnoException e) {
                            customBundle.putString("message", "ErrnoException: " + e.getMessage());
                        }
                    } else {
                        customBundle.putString("message", "File not found");
                    }
                    break;
                }
                case "mt:setOwner": {
                    File file = getFileForDocId(documentId, true);
                    if (file != null) {
                        try {
                            int uid = extras.getInt("uid", -1);
                            int gid = extras.getInt("gid", -1);
                            if (uid == -1 || gid == -1) {
                                customBundle.putString("message", "Invalid uid/gid");
                            } else {
                                Os.chown(file.getPath(), uid, gid);
                                customBundle.putBoolean("result", true);
                            }
                        } catch (ErrnoException e) {
                            customBundle.putString("message", "ErrnoException: " + e.getMessage());
                        }
                    } else {
                        customBundle.putString("message", "File not found");
                    }
                    break;
                }
                default:
                    customBundle.putString("message", "Unsupported method: " + method);
            }
        } catch (FileNotFoundException e) {
            customBundle.putString("message", "File not found: " + e.getMessage());
        } catch (SecurityException e) {
            customBundle.putString("message", "Security error: " + e.getMessage());
        } catch (Exception e) {
            Log.e(TAG, "Error in call method", e);
            customBundle.putString("message", "Operation failed: " + e.getMessage());
        }
        return customBundle;
    }

    @Override
    public final String createDocument(String parentDocumentId, String mimeType, String displayName) throws FileNotFoundException {
        if (displayName == null || displayName.isEmpty()) {
            throw new FileNotFoundException("Display name is empty");
        }
        
        File parentFile = getFileForDocId(parentDocumentId, true);
        if (parentFile != null) {
            // Sanitize filename
            String safeName = sanitizeFilename(displayName);
            File newFile = new File(parentFile, safeName);
            
            int noConflictId = 2;
            while (newFile.exists()) {
                newFile = new File(parentFile, safeName + " (" + noConflictId + ")");
                noConflictId++;
            }
            
            try {
                boolean succeeded = MIME_TYPE_DIR.equals(mimeType)
                    ? newFile.mkdir()
                    : newFile.createNewFile();

                if (succeeded) {
                    // Log for debugging
                    Log.d(TAG, "Created document: " + newFile.getAbsolutePath());
                    return parentDocumentId + "/" + newFile.getName();
                }
            } catch (IOException e) {
                Log.e(TAG, "Error creating document", e);
                throw new FileNotFoundException("Failed to create document: " + e.getMessage());
            }
        }
        throw new FileNotFoundException("Failed to create document in " + parentDocumentId + " with name " + displayName);
    }
    
    private String sanitizeFilename(String filename) {
        // Remove any path separators
        return filename.replaceAll("[\\\\/:*?\"<>|]", "_");
    }

    /**
     * Add a representation of a file to a cursor
     */
    private void includeFile(MatrixCursor result, String docId, File file) throws FileNotFoundException {
        if (file == null) {
            file = getFileForDocId(docId, true);
        }

        // Root directory - show virtual root
        if (file == null) {
            Context ctx = getContext();
            String title = "XoDos";
            if (ctx != null) {
                ApplicationInfo appInfo = ctx.getApplicationInfo();
                title = appInfo.loadLabel(ctx.getPackageManager()).toString();
            }

            MatrixCursor.RowBuilder row = result.newRow();
            row.add(Document.COLUMN_DOCUMENT_ID, this.pkgName);
            row.add(Document.COLUMN_DISPLAY_NAME, title);
            row.add(Document.COLUMN_SIZE, 0);
            row.add(Document.COLUMN_MIME_TYPE, MIME_TYPE_DIR);
            row.add(Document.COLUMN_LAST_MODIFIED, 0);
            row.add(Document.COLUMN_FLAGS, 
                Document.FLAG_DIR_SUPPORTS_CREATE | 
                Document.FLAG_SUPPORTS_DELETE |
                Document.FLAG_SUPPORTS_RENAME |
                Document.FLAG_SUPPORTS_SETTINGS |
                Document.FLAG_DIR_PREFERS_LAST_MODIFIED);
            return;
        }

        int flags = 0;
        
        // Set flags based on file type and permissions
        if (file.isDirectory()) {
            flags |= Document.FLAG_DIR_SUPPORTS_CREATE |
                     Document.FLAG_DIR_PREFERS_LAST_MODIFIED;
        } else {
            if (file.canWrite()) {
                flags |= Document.FLAG_SUPPORTS_WRITE;
            }
            if (isImageFile(file)) {
                flags |= Document.FLAG_SUPPORTS_THUMBNAIL;
            }
        }

        // Always include these flags for full control
        flags |= Document.FLAG_SUPPORTS_SETTINGS |  // This enables permission management
                 Document.FLAG_SUPPORTS_COPY | 
                 Document.FLAG_SUPPORTS_MOVE |
                 Document.FLAG_SUPPORTS_DELETE |
                 Document.FLAG_SUPPORTS_RENAME;

        String displayName;
        String path = file.getPath();

        // For virtual directories, show friendly names
        if (path.equals(this.filesDir.getPath())) {
            displayName = VIRTUAL_FILES;
        } else if (path.equals(this.dataDir.getPath())) {
            displayName = VIRTUAL_DATA;
        } else {
            displayName = file.getName();
        }

        MatrixCursor.RowBuilder row = result.newRow();
        row.add(DocumentsContract.Document.COLUMN_DOCUMENT_ID, docId);
        row.add(DocumentsContract.Document.COLUMN_DISPLAY_NAME, displayName);
        row.add(DocumentsContract.Document.COLUMN_SIZE, file.length());
        row.add(DocumentsContract.Document.COLUMN_MIME_TYPE, getMimeType(file));
        row.add(DocumentsContract.Document.COLUMN_LAST_MODIFIED, file.lastModified());
        row.add(DocumentsContract.Document.COLUMN_FLAGS, flags);
        row.add("mt_path", file.getAbsolutePath());
        
        // Add extended file information (mode, uid, gid, symlink target)
        try {
            StructStat lstat = Os.lstat(path);
            StringBuilder sb = new StringBuilder()
                .append(lstat.st_mode)
                .append("|").append(lstat.st_uid)
                .append("|").append(lstat.st_gid);
            if ((lstat.st_mode & S_IFMT) == S_IFLNK) {
                sb.append("|").append(Os.readlink(path));
            }
            row.add("mt_extras", sb.toString());
        } catch (Exception e) {
            Log.e(TAG, "Error getting file stats", e);
        }
    }
    
    private boolean isImageFile(File file) {
        String mime = getMimeType(file);
        return mime != null && mime.startsWith("image/");
    }

    @Override
    public final void deleteDocument(String documentId) throws FileNotFoundException {
        File file = getFileForDocId(documentId, true);
        if (file == null || !deleteFileOrDirectory(file)) {
            throw new FileNotFoundException("Failed to delete document ".concat(documentId));
        }
    }

    @Override
    public final String getDocumentType(String documentId) throws FileNotFoundException {
        File file = getFileForDocId(documentId, true);
        return file == null ? MIME_TYPE_DIR : getMimeType(file);
    }

    @Override
    public final boolean isChildDocument(String parentDocumentId, String documentId) {
        return documentId != null && documentId.startsWith(parentDocumentId);
    }

    @Override
    public final String moveDocument(String sourceDocumentId, String sourceParentDocumentId, String targetParentDocumentId) throws FileNotFoundException {
        File sourceFile = getFileForDocId(sourceDocumentId, true);
        File targetParentFile = getFileForDocId(targetParentDocumentId, true);
        if (sourceFile != null && targetParentFile != null) {
            File targetFile = new File(targetParentFile, sourceFile.getName());
            if (!targetFile.exists() && sourceFile.renameTo(targetFile)) {
                return targetParentDocumentId + "/" + targetFile.getName();
            }
        }
        throw new FileNotFoundException("Failed to move document " + sourceDocumentId + " to " + targetParentDocumentId);
    }

    @Override
    public final boolean onCreate() {
        return true;
    }

    @Override
    public final ParcelFileDescriptor openDocument(String documentId, String mode, CancellationSignal cancellationSignal) throws FileNotFoundException {
        File file = getFileForDocId(documentId, false);
        if (file != null) {
            return ParcelFileDescriptor.open(file, ParcelFileDescriptor.parseMode(mode));
        } else {
            throw new FileNotFoundException(documentId + " not found");
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public final Cursor queryChildDocuments(String parentDocumentId, String[] projection, String sortOrder) throws FileNotFoundException {
        // Call the new API with null queryArgs for backward compatibility
        return queryChildDocuments(parentDocumentId, projection, sortOrder, null);
    }

    @SuppressWarnings("deprecation")
    public final Cursor queryChildDocuments(String parentDocumentId, String[] projection, String sortOrder, Bundle queryArgs) throws FileNotFoundException {
        if (parentDocumentId.endsWith("/")) {
            parentDocumentId = parentDocumentId.substring(0, parentDocumentId.length() - 1);
        }
        
        MatrixCursor cursor = new MatrixCursor(projection != null ? projection : DEFAULT_DOCUMENT_PROJECTION);
        File parent = getFileForDocId(parentDocumentId, true);
        
        // Virtual root - list available virtual directories (like Termux)
        if (parent == null) {
            // Show "files" and "data" as virtual directories
            includeFile(cursor, parentDocumentId + "/" + VIRTUAL_FILES, this.filesDir);
            includeFile(cursor, parentDocumentId + "/" + VIRTUAL_DATA, this.dataDir);
        } else {
            File[] children = parent.listFiles();
            if (children != null) {
                List<File> sortedChildren = sortFiles(children, sortOrder);
                for (File child : sortedChildren) {
                    includeFile(cursor, parentDocumentId + "/" + child.getName(), child);
                }
            }
        }
        return cursor;
    }
    
    private List<File> sortFiles(File[] files, String sortOrder) {
        List<File> fileList = new ArrayList<>();
        if (files == null) {
            return fileList;
        }
        Collections.addAll(fileList, files);
        
        if (sortOrder != null) {
            Comparator<File> comparator = null;
            boolean descending = sortOrder.startsWith("-");
            String sortField = descending ? sortOrder.substring(1) : sortOrder;
            
            switch (sortField) {
                case Document.COLUMN_DISPLAY_NAME:
                    comparator = Comparator.comparing(File::getName, String.CASE_INSENSITIVE_ORDER);
                    break;
                case Document.COLUMN_SIZE:
                    comparator = Comparator.comparingLong(File::length);
                    break;
                case Document.COLUMN_LAST_MODIFIED:
                    comparator = Comparator.comparingLong(File::lastModified);
                    break;
            }
            
            if (comparator != null) {
                if (descending) {
                    comparator = comparator.reversed();
                }
                fileList.sort(comparator);
            }
        }
        
        return fileList;
    }

    @Override
    public final Cursor queryDocument(String documentId, String[] projection) throws FileNotFoundException {
        MatrixCursor result = new MatrixCursor(projection != null ? projection : DEFAULT_DOCUMENT_PROJECTION);
        includeFile(result, documentId, null);
        return result;
    }

    @SuppressWarnings("deprecation")
    @Override
    public Cursor querySearchDocuments(String rootId, String[] projection, Bundle queryArgs) throws FileNotFoundException {
        String query = queryArgs != null ? queryArgs.getString(DocumentsContract.QUERY_ARG_DISPLAY_NAME) : null;
        MatrixCursor cursor = new MatrixCursor(projection != null ? projection : DEFAULT_DOCUMENT_PROJECTION);
        
        if (query != null && !query.trim().isEmpty()) {
            String searchQuery = query.trim().toLowerCase();
            
            // Search in files directory
            searchInDirectory(filesDir, this.pkgName + "/" + VIRTUAL_FILES, searchQuery, cursor);
            // Search in data directory
            searchInDirectory(dataDir, this.pkgName + "/" + VIRTUAL_DATA, searchQuery, cursor);
        }
        
        return cursor;
    }
    
    private void searchInDirectory(File dir, String baseDocId, String query, MatrixCursor cursor) {
        if (!dir.exists() || !dir.isDirectory()) {
            return;
        }
        
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.getName().toLowerCase().contains(query)) {
                    try {
                        includeFile(cursor, baseDocId + "/" + file.getName(), file);
                    } catch (FileNotFoundException e) {
                        Log.e(TAG, "Error including file in search results", e);
                    }
                }
                if (file.isDirectory()) {
                    searchInDirectory(file, baseDocId + "/" + file.getName(), query, cursor);
                }
            }
        }
    }

    @Override
    public final Cursor queryRoots(String[] projection) {
        Context context = getContext();
        if (context == null) {
            return new MatrixCursor(projection != null ? projection : DEFAULT_ROOT_PROJECTION);
        }
        
        ApplicationInfo appInfo = context.getApplicationInfo();
        String title = appInfo.loadLabel(context.getPackageManager()).toString();

        MatrixCursor result = new MatrixCursor(projection != null ? projection : DEFAULT_ROOT_PROJECTION);
        MatrixCursor.RowBuilder row = result.newRow();
        row.add(Root.COLUMN_ROOT_ID, this.pkgName);
        row.add(Root.COLUMN_DOCUMENT_ID, this.pkgName);
        row.add(Root.COLUMN_SUMMARY, "XoDos System File Manager");
        
        // Fixed: Removed FLAG_SUPPORTS_SETTINGS as it doesn't exist in Root class
        int rootFlags = Root.FLAG_SUPPORTS_CREATE | 
                        Root.FLAG_SUPPORTS_SEARCH | 
                        Root.FLAG_SUPPORTS_IS_CHILD |
                        Root.FLAG_LOCAL_ONLY;
        
        // Add FLAG_SUPPORTS_SETTINGS only if API level supports it
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                // Use reflection to check if the flag exists
                java.lang.reflect.Field field = Root.class.getField("FLAG_SUPPORTS_SETTINGS");
                rootFlags |= (int) field.get(null);
            } catch (Exception e) {
                Log.d(TAG, "FLAG_SUPPORTS_SETTINGS not available on this API level");
            }
        }
        
        row.add(Root.COLUMN_FLAGS, rootFlags);
        row.add(Root.COLUMN_TITLE, title);
        row.add(Root.COLUMN_MIME_TYPES, "*/*");
        row.add(Root.COLUMN_AVAILABLE_BYTES, filesDir.getFreeSpace());
        row.add(Root.COLUMN_ICON, appInfo.icon);
        return result;
    }

    @Override
    @SuppressWarnings("deprecation")
    public final void removeDocument(String documentId, String parentDocumentId) throws FileNotFoundException {
        // Call deleteDocument for backward compatibility
        deleteDocument(documentId);
    }

    // Note: The single-argument removeDocument method was added in API 29
    // We'll only override it if we're targeting that API level
    @SuppressWarnings("unused")
    private void removeDocumentApi29(String documentId) throws FileNotFoundException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            deleteDocument(documentId);
        }
    }

    @Override
    public final String renameDocument(String documentId, String displayName) throws FileNotFoundException {
        if (displayName == null || displayName.isEmpty()) {
            throw new FileNotFoundException("Display name is empty");
        }
        
        File file = getFileForDocId(documentId, true);
        if (file == null) {
            throw new FileNotFoundException("Document not found: " + documentId);
        }
        
        String safeName = sanitizeFilename(displayName);
        File newFile = new File(file.getParentFile(), safeName);
        
        if (newFile.exists()) {
            throw new FileNotFoundException("File already exists: " + safeName);
        }
        
        if (!file.renameTo(newFile)) {
            throw new FileNotFoundException("Failed to rename document " + documentId + " to " + displayName);
        }
        
        int parentIdx = documentId.lastIndexOf('/', documentId.length() - 2);
        return parentIdx >= 0 ? documentId.substring(0, parentIdx) + "/" + safeName : this.pkgName + "/" + safeName;
    }

    @SuppressWarnings("deprecation")
    @Override
    public AssetFileDescriptor openDocumentThumbnail(String documentId, Point sizeHint, CancellationSignal signal) throws FileNotFoundException {
        File file = getFileForDocId(documentId, true);
        if (file != null && isImageFile(file)) {
            try {
                ParcelFileDescriptor pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
                return new AssetFileDescriptor(pfd, 0, file.length());
            } catch (Exception e) {
                Log.e(TAG, "Error opening thumbnail", e);
            }
        }
        return null;
    }

    @Override
    public void shutdown() {
        super.shutdown();
        // Clean up resources
        MIME_CACHE.clear();
        Log.d(TAG, "Provider shutdown");
    }
}